package com.smkn9semarang.quizzz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class easyhh extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easyhh);
    }
}